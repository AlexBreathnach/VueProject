package com.example.backend.controller;

import com.example.backend.dto.ArticleDTO;
import com.example.backend.model.Article;
import com.example.backend.service.ArticleService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/api/articles")
@CrossOrigin(origins = {"http://localhost:5173", "http://localhost:8081"})
public class ArticleController {

    private final ArticleService service;

    public ArticleController(ArticleService service) {
        this.service = service;
    }

    @GetMapping
    public List<Article> all() {
        return service.findAll();
    }

    @GetMapping("/{id}")
    public Article one(@PathVariable Long id) {
        return service.findById(id);
    }

    @PostMapping
    public ResponseEntity<Article> create(@Valid @RequestBody ArticleDTO dto) {
        Article created = service.create(dto);
        return ResponseEntity.created(URI.create("/api/articles/" + created.getId())).body(created);
    }

    @PutMapping("/{id}")
    public Article update(@PathVariable Long id, @Valid @RequestBody ArticleDTO dto) {
        return service.update(id, dto);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        service.delete(id);
        return ResponseEntity.noContent().build();
    }
}
