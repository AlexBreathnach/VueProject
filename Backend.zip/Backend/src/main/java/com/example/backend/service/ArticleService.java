package com.example.backend.service;

import com.example.backend.dto.ArticleDTO;
import com.example.backend.model.Article;
import com.example.backend.model.Category;
import com.example.backend.repository.ArticleRepository;
import com.example.backend.repository.CategoryRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@Service // Business logic stays here
@Transactional // Ensures DB operations are atomic per method (commit/rollback)
public class ArticleService {

    private final ArticleRepository articleRepo;
    private final CategoryRepository categoryRepo;

    public ArticleService(ArticleRepository articleRepo, CategoryRepository categoryRepo) {
        this.articleRepo = articleRepo;
        this.categoryRepo = categoryRepo;
    }

    public List<Article> findAll() {
        return articleRepo.findAll(); // SELECT * FROM article
    }

    public Article findById(Long id) {
        return articleRepo.findById(id).orElseThrow(() -> new IllegalArgumentException("Article not found"));
    }

    public Article create(ArticleDTO dto) {
        Category category = categoryRepo.findById(dto.getCategoryId())
                .orElseThrow(() -> new IllegalArgumentException("Category not found"));

        Article a = new Article();
        a.setTitle(dto.getTitle().trim());
        a.setContent(dto.getContent().trim());
        a.setAuthor(dto.getAuthor().trim());
        a.setPublishedAt(LocalDateTime.now()); // set when created
        a.setCategory(category);               // attach FK

        return articleRepo.save(a); // INSERT
    }

    public Article update(Long id, ArticleDTO dto) {
        Article a = findById(id);
        Category category = categoryRepo.findById(dto.getCategoryId())
                .orElseThrow(() -> new IllegalArgumentException("Category not found"));

        a.setTitle(dto.getTitle().trim());
        a.setContent(dto.getContent().trim());
        a.setAuthor(dto.getAuthor().trim());
        a.setCategory(category);

        return articleRepo.save(a); // UPDATE
    }

    public void delete(Long id) {
        articleRepo.delete(findById(id)); // DELETE
    }
}
