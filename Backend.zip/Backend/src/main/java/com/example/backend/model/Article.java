package com.example.backend.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity // links to "article" table
public class Article {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) // auto-increment for PK
    private Long id;

    @Column(nullable = false)
    private String title;

    @Column(nullable = false, columnDefinition = "TEXT") // Long text content
    private String content;

    @Column(nullable = false)
    private String author;

    // Stored as DATETIME in MySQL; LocalDateTime in Java
    private LocalDateTime publishedAt;

    // Many Articles -> One Category (owning side).
    // @JoinColumn adds a foreign key column "category_id" in "article".

    @ManyToOne(optional = false, fetch = FetchType.LAZY)
    @JoinColumn(name = "category_id", nullable = false)
    private Category category;

    public Article() {}

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getContent() { return content; }
    public void setContent(String content) { this.content = content; }

    public String getAuthor() { return author; }
    public void setAuthor(String author) { this.author = author; }

    public LocalDateTime getPublishedAt() { return publishedAt; }
    public void setPublishedAt(LocalDateTime publishedAt) { this.publishedAt = publishedAt; }

    public Category getCategory() { return category; }
    public void setCategory(Category category) { this.category = category; }
}
