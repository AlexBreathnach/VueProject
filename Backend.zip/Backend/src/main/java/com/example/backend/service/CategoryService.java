package com.example.backend.service;

import com.example.backend.dto.CategoryDTO;
import com.example.backend.model.Category;
import com.example.backend.repository.ArticleRepository;
import com.example.backend.repository.CategoryRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service // Marks this class as a service layer
@Transactional // Opens a transaction for public methods (commit/rollback automatically)
public class CategoryService {

    private final CategoryRepository categoryRepo;
    private final ArticleRepository articleRepo;

    public CategoryService(CategoryRepository categoryRepo, ArticleRepository articleRepo) {
        this.categoryRepo = categoryRepo;
        this.articleRepo = articleRepo;
    }

    public List<Category> findAll() {
        return categoryRepo.findAll();
    }

    public Category create(CategoryDTO dto) {
        //  Validation runs before this
        Category c = new Category();
        c.setName(dto.getName().trim());
        return categoryRepo.save(c); // INSERT into DB
    }

    public void delete(Long id) {
        Category c = categoryRepo.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Category not found"));

        // Safety rule: do not delete a category if it still has articles

        if (articleRepo.findByCategory(c).isEmpty()) {
            categoryRepo.delete(c); // DELETE from DB
        } else {
            throw new IllegalStateException("Cannot delete category with existing articles");
        }
    }
}
