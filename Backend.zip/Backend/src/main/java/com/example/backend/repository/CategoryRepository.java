package com.example.backend.repository;

import com.example.backend.model.Category;
import org.springframework.data.jpa.repository.JpaRepository;

// Spring Data JPA creates CRUD methods automatically (save, findAll, findById, delete)
public interface CategoryRepository extends JpaRepository<Category, Long> {

}
