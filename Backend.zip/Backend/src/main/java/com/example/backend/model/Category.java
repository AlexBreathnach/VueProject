package com.example.backend.model;

import jakarta.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity // Marks this class as a JPA entity mapped to a "category" table
public class Category {

    @Id // Primary key
    @GeneratedValue(strategy = GenerationType.IDENTITY) // Auto-increment
    private Long id;

    @Column(nullable = false, unique = true, length = 50) // NOT NULL, UNIQUE, length capped
    private String name;

    // One Category = Many Articles (inverse side).
    // mappedBy = "category" must match the field name in Article.
    // cascade = ALL: propagate changes (persist/remove) from parent to children.
    // orphanRemoval = true: removing an Article from this list deletes it in DB if no other reference holds it.

    @OneToMany(mappedBy = "category", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Article> articles = new ArrayList<>();

    public Category() {}
    public Category(String name) { this.name = name; }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public List<Article> getArticles() { return articles; }
    public void setArticles(List<Article> articles) { this.articles = articles; }

    public int countArticlesByAuthor(String author) {
        int count = 0; // for-loop demo
        for (Article a : articles) {
            if (a != null && a.getAuthor() != null && a.getAuthor().equals(author)) {
                count++;
            }
        }
        return count;
    }
}
