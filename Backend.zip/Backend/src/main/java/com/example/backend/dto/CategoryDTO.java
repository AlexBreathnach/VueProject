package com.example.backend.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

// DTO = request shape for Category (keeps controllers decoupled from entities)

public class CategoryDTO {
    @NotBlank                 // must contain non-whitespace
    @Size(min = 3, max = 50)  // Length constraint = same as column length
    private String name;

    public CategoryDTO() {}
    public CategoryDTO(String name) { this.name = name; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
}
