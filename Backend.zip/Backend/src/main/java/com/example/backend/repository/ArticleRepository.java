package com.example.backend.repository;

import com.example.backend.model.Article;
import com.example.backend.model.Category;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ArticleRepository extends JpaRepository<Article, Long> {
    // Used for safety check before deleting a Category
    List<Article> findByCategory(Category category);
}
