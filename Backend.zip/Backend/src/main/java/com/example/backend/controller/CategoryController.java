package com.example.backend.controller;

import com.example.backend.dto.CategoryDTO;
import com.example.backend.model.Category;
import com.example.backend.service.CategoryService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;

@RestController // REST endpoints
@RequestMapping("/api/categories") // Base path for all Category routes
@CrossOrigin(origins = {"http://localhost:5173", "http://localhost:8081"})
public class CategoryController {

    private final CategoryService service;

    public CategoryController(CategoryService service) {
        this.service = service;
    }

    @GetMapping // GET /api/categories
    public List<Category> all() {
        return service.findAll();
    }

    @PostMapping // POST /api/categories
    public ResponseEntity<Category> create(@Valid @RequestBody CategoryDTO dto) {
        // @Valid triggers jakarta.validation on DTO before service runs

        Category created = service.create(dto);
        return ResponseEntity.created(URI.create("/api/categories/" + created.getId())).body(created);
    }

    @DeleteMapping("/{id}") // DELETE /api/categories/{id}
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        service.delete(id);
        return ResponseEntity.noContent().build();
    }
}
