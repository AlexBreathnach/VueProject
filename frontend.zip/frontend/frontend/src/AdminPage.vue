<script setup>
import { ref, onMounted } from "vue";
import { listCategories, createCategory, deleteCategory } from "../api/categories";
import { listArticles, createArticle, deleteArticle } from "../api/articles";

const categories = ref([]);
const articles   = ref([]);

const newCategory = ref({ name: "" });
const newArticle  = ref({ title: "", content: "", author: "", categoryId: null });

const error = ref("");

async function refresh() {
  error.value = "";
  try {
    categories.value = await listCategories();
    articles.value   = await listArticles();
    if (categories.value.length && !newArticle.value.categoryId) {
      newArticle.value.categoryId = categories.value[0].id;
    }
  } catch (e) {
    error.value = String(e);
  }
}

async function addCategory() {
  if (!newCategory.value.name?.trim()) return;
  try {
    await createCategory({ name: newCategory.value.name.trim() });
    newCategory.value.name = "";
    await refresh();
  } catch (e) {
    error.value = String(e);
  }
}

async function removeCategory(id) {
  try {
    await deleteCategory(id);
  } catch {
    alert("Cannot delete category with existing articles.");
  }
  await refresh();
}

async function addArticle() {
  const p = { ...newArticle.value };
  if (!p.title?.trim() || !p.content?.trim() || !p.author?.trim() || !p.categoryId) return;
  try {
    await createArticle(p);
    newArticle.value = { title: "", content: "", author: "", categoryId: categories.value[0]?.id || null };
    await refresh();
  } catch (e) {
    error.value = String(e);
  }
}

async function removeArticle(id) {
  try {
    await deleteArticle(id);
    await refresh();
  } catch (e) {
    error.value = String(e);
  }
}

onMounted(refresh);
</script>

<template>
  <div>
    <p v-if="error" style="color:#b00; white-space:pre-wrap">Error: {{ error }}</p>

    <div class="row">
      <!-- Categories -->
      <section class="card" style="flex:1">
        <h2>Categories</h2>
        <form @submit.prevent="addCategory" class="row">
          <div style="flex:1">
            <label>Name</label>
            <input v-model="newCategory.name" placeholder="e.g. Technology" />
          </div>
          <div>
            <label>&nbsp;</label>
            <button>Add</button>
          </div>
        </form>

        <ul class="list" style="margin-top:1rem">
          <li v-for="c in categories" :key="c.id">
            <span>{{ c.name }}</span>
            <button class="secondary" @click="removeCategory(c.id)">Delete</button>
          </li>
        </ul>
      </section>

      <!-- Articles -->
      <section class="card" style="flex:2">
        <h2>Articles</h2>

        <form @submit.prevent="addArticle" class="row">
          <div style="flex:1">
            <label>Title</label>
            <input v-model="newArticle.title" placeholder="Title" />
          </div>
          <div style="flex:1">
            <label>Author</label>
            <input v-model="newArticle.author" placeholder="Author" />
          </div>
          <div style="flex:1">
            <label>Category</label>
            <select v-model="newArticle.categoryId">
              <option v-for="c in categories" :key="c.id" :value="c.id">{{ c.name }}</option>
            </select>
          </div>
          <div style="flex-basis:100%">
            <label>Content</label>
            <textarea v-model="newArticle.content" rows="4" placeholder="Write something..." />
          </div>
          <div>
            <label>&nbsp;</label>
            <button>Add Article</button>
          </div>
        </form>

        <ul class="list" style="margin-top:1rem">
          <li v-for="a in articles" :key="a.id">
            <div style="max-width:70%">
              <strong>{{ a.title }}</strong> — {{ a.author }}
              <div style="font-size:.9rem; color:#666">Category: {{ a.category?.name || a.categoryId }}</div>
            </div>
            <div class="row">
              <button class="secondary" @click="removeArticle(a.id)">Delete</button>
            </div>
          </li>
        </ul>
      </section>
    </div>
  </div>
</template>
