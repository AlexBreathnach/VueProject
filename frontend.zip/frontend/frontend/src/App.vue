<template>
  <div class="container">
    <h1>Articles CMS</h1>
    <router-view />
  </div>
</template>

<style>
      .container { max-width: 900px; margin: 2rem auto; padding: 0 1rem; font-family: system-ui, sans-serif; }

      h1 { margin-bottom: 1rem; }
          .card { border: 1px solid #ddd; padding: 1rem; border-radius: 8px; margin-bottom: 1rem; }
          .row { display: flex; flex-wrap: wrap; gap: 1rem; }

      input, select, textarea { width: 100%; padding: .6rem; border: 1px solid #ccc; border-radius: 6px; }

      button { padding: .6rem 1rem; border-radius: 6px; border: 1px solid #0a7; background: #0c8; color: #fff; cursor: pointer; }

      button.secondary { background: #888; border-color: #666; }
          .list { list-style: none; padding: 0; }

      .list li { display: flex; justify-content: space-between; align-items: center; padding: .4rem 0; border-bottom: 1px dashed #ddd; }

      label { font-size: .9rem; color: #333; display:block; margin-bottom:.25rem; }

</style>
