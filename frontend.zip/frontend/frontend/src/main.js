import { createApp } from "vue";
import App from "./App.vue";
import router from "./router";

import "./style.css"; // keep Vite default styles if present

createApp(App).use(router).mount("#app");
