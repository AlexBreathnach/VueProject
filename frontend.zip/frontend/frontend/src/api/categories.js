// src/api/categories.js
import http from "./http";

export const listCategories = () => http.get("/categories").then(r => r.data);
export const createCategory  = (payload) => http.post("/categories", payload).then(r => r.data);
export const deleteCategory  = (id) => http.delete(`/categories/${id}`);
