// src/api/articles.js
import http from "./http";

export const listArticles  = () => http.get("/articles").then(r => r.data);
export const createArticle = (payload) => http.post("/articles", payload).then(r => r.data);
export const deleteArticle = (id) => http.delete(`/articles/${id}`);
