// src/router/index.js
import { createRouter, createWebHistory } from "vue-router";
import AdminPage from "../pages/AdminPage.vue";

const routes = [
    { path: "/", component: AdminPage }
];

export default createRouter({
    history: createWebHistory(),
    routes,
});
